﻿using System.Data;
using System.Data.SqlClient;

namespace QuanLyThuVien_CuoiKyWindows_NguyenThanhTrung_19110304.Classes
{
    public class Database
    {
        
        private static string DBname = "QuanLyThuVien";
        private static string connectString = @"DESKTOP-K8KKIHD\SQLEXPRESS";

        SqlConnection con = new SqlConnection(string.Format(@"data source = {0} ; database= {1}; integrated security=True", connectString, DBname));
        
        // get the connection
        public SqlConnection getConnection
        {
            get
            {
                return con;
            }
        }

        // open the connection
        public void openConnection()
        {
            if ((con.State == ConnectionState.Closed))
            {
                con.Open();
            }

        }


        // close the connection
        public void closeConnection()
        {
            if ((con.State == ConnectionState.Open))
            {
                con.Close();

            }
        }

    }
}
