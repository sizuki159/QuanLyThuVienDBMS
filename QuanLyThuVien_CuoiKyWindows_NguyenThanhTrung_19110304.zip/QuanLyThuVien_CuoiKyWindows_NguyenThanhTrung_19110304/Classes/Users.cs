﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Globalization;
using System.Drawing;
using System.IO;
using System.Drawing.Imaging;

namespace QuanLyThuVien_CuoiKyWindows_NguyenThanhTrung_19110304.Classes
{


    public class Users
    {
        // Biến static dùng để lưu phiên và thông tin đăng nhập
        public static bool isLogin = false;
        public static Dictionary<string, object> InfoUserLogin = new Dictionary<string, object>();

        private static Database database = new Database();

        #region Properties Class

        public enum User_Role
        {
            Admin,
            Teacher,
            Student,
            Error
        }

        public enum User_Status
        {
            Active,
            Inactive,
            Disabled,
            Ban,
            Error
        }
        private const string TableName = "users";
        public string Username { get; set; }
        public string Password { get; set; }
        public string Fullname { get; set; }
        public string Email { get; set; }
        public User_Role Role { get; set; }
        public string Code { get; set; }
        public User_Status Status { get; set; }
        public string Gender { get; set; }
        public DateTime Birthdate { get; set; }
        public Image Image { get; set; }
        
        #endregion

        public Users() { }
        public Users(string username, string password)
        {
            Username = username;
            Password = password;
        }

        private void updateRole(string role)
        {
            switch(role.ToLower().Trim())
            {
                case "admin":
                    Role = User_Role.Admin;
                    break;
                case "teacher":
                    Role = User_Role.Teacher;
                    break;
                case "student":
                    Role = User_Role.Student;
                    break;
                default:
                    Role = User_Role.Error;
                    break;
            }
        }
        private void updateStatus(string status)
        {
            switch (status.ToLower().Trim())
            {
                case "active":
                    Status = User_Status.Active;
                    break;
                case "disabled":
                    Status = User_Status.Disabled;
                    break;
                case "inactive":
                    Status = User_Status.Inactive;
                    break;
                default:
                    Status = User_Status.Error;
                    break;
            }
        }

        #region Check Username Exist
        public static bool isCheckUsernameExist(string username)
        {
            Database database = new Database();
            SqlCommand command = new SqlCommand();
            command.Connection = database.getConnection;
            command.CommandText = "SELECT dbo.checkUsernameExist(@username) AS isExist";
            command.Parameters.Add("@username", SqlDbType.VarChar).Value = username;
            SqlDataAdapter adapter = new SqlDataAdapter(command);
            DataTable table = new DataTable();
            adapter.Fill(table);
            bool isExist = bool.Parse(table.Rows[0]["isExist"].ToString());
            if (isExist)
                return true;
            return false;
        }

        // Check username exist on database
        public bool isCheckUsernameExist()
        {
            Database database = new Database();
            SqlCommand command = new SqlCommand();
            command.Connection = database.getConnection;
            command.CommandText = "SELECT dbo.checkUsernameExist(@username) AS isExist";
            command.Parameters.Add("@username", SqlDbType.VarChar).Value = Username;
            SqlDataAdapter adapter = new SqlDataAdapter(command);
            DataTable table = new DataTable();
            adapter.Fill(table);
            bool isExist = bool.Parse(table.Rows[0]["isExist"].ToString());
            if(isExist)
                return true;
            return false;
        }

        // Check username exist on database
        public bool isCheckEmailExist()
        {
            SqlCommand command = new SqlCommand();
            command.Connection = database.getConnection;
            command.CommandText = "SELECT id FROM users WHERE email = @email";
            command.Parameters.Add("@email", SqlDbType.VarChar).Value = Email;
            SqlDataAdapter adapter = new SqlDataAdapter(command);
            DataTable table = new DataTable();
            adapter.Fill(table);
            if (table.Rows.Count > 0)
                return true;
            return false;
        }

        #endregion

        #region Check Code User
        public bool isCheckCodeExist()
        {
            Database database = new Database();
            SqlCommand command = new SqlCommand();
            command.Connection = database.getConnection;
            command.CommandText = "SELECT dbo.checkUserCodeExist(@code) AS isExist";
            command.Parameters.Add("@code", SqlDbType.NVarChar).Value = Code;
            SqlDataAdapter adapter = new SqlDataAdapter(command);
            DataTable table = new DataTable();
            adapter.Fill(table);
            bool isExist = bool.Parse(table.Rows[0]["isExist"].ToString());
            if (isExist)
                return true;
            return false;
        }

        public static bool isCheckCodeExist(string code)
        {
            Database database = new Database();
            SqlCommand command = new SqlCommand();
            command.Connection = database.getConnection;
            command.CommandText = "SELECT dbo.checkUserCodeExist(@code) AS isExist";
            command.Parameters.Add("@code", SqlDbType.VarChar).Value = code;
            SqlDataAdapter adapter = new SqlDataAdapter(command);
            DataTable table = new DataTable();
            adapter.Fill(table);
            bool isExist = bool.Parse(table.Rows[0]["isExist"].ToString());
            if (isExist)
                return true;
            return false;
        }

        #endregion

        #region Check User Login
        public bool isCheckLogin()
        {
            Database database = new Database();
            SqlCommand command = new SqlCommand();
            command.Connection = database.getConnection;
            command.CommandText = "SELECT * FROM "+ TableName + " WHERE username = @user AND password = @pass";
            command.Parameters.Add(@"user", SqlDbType.VarChar).Value = Username;
            command.Parameters.Add(@"pass", SqlDbType.VarChar).Value = Password;
            SqlDataAdapter adapter = new SqlDataAdapter(command);
            DataSet dataSet = new DataSet();
            adapter.Fill(dataSet);
            if (dataSet.Tables[0].Rows.Count > 0)
            {
                try
                {
                    updateStatus(dataSet.Tables[0].Rows[0]["status"].ToString());
                    updateRole(dataSet.Tables[0].Rows[0]["role"].ToString());
                    Fullname = dataSet.Tables[0].Rows[0]["fullname"].ToString();
                    Gender = dataSet.Tables[0].Rows[0]["gender"].ToString();
                    Code = dataSet.Tables[0].Rows[0]["code"].ToString();
                    string bdate = dataSet.Tables[0].Rows[0]["birthdate"].ToString();
                    if (!string.IsNullOrEmpty(bdate))
                        Birthdate = Convert.ToDateTime(bdate);

                    return true;
                } catch { return false; }

            }
            return false;
        }

        public static bool isCheckLogin(string username, string password)
        {
            Database database = new Database();
            SqlCommand command = new SqlCommand();
            command.Connection = database.getConnection;
            command.CommandText = "SELECT id FROM "+ TableName + " WHERE username = @user AND password = @pass";
            command.Parameters.Add("@user", SqlDbType.VarChar).Value = username;
            command.Parameters.Add("@pass", SqlDbType.VarChar).Value = password;
            SqlDataAdapter adapter = new SqlDataAdapter(command);
            DataSet dataSet = new DataSet();
            adapter.Fill(dataSet);
            if(dataSet.Tables[0].Rows.Count > 0)
                return true;
            return false;
        }

        public bool isUpdateSessionLogin()
        {
            try
            {
                isLogin = true;
                InfoUserLogin.Add("username", Username);
                InfoUserLogin.Add("fullname", Fullname);
                InfoUserLogin.Add("role", Role);
                InfoUserLogin.Add("gender", Gender);
                InfoUserLogin.Add("birthdate", Birthdate);
                InfoUserLogin.Add("status", Status);
                InfoUserLogin.Add("code", Code);

                return true;
            }
            catch { return false; }
        }

        #endregion


        #region Insert User

        public bool isInsert()
        {
            database.openConnection();
            SqlCommand command = new SqlCommand();
            command.Connection = database.getConnection;
            command.CommandText = "INSERT INTO users(fullname, username, password, gender, birthdate, role, status, images, created_time, code, email) " +
                                "VALUES(@fullname, @username, @password, @gender, @birthdate, @role, @status, @images, @created, @code, @email)";
            command.Parameters.Add("@fullname", SqlDbType.NVarChar).Value = Fullname;
            command.Parameters.Add("@username", SqlDbType.NVarChar).Value = Username;
            command.Parameters.Add("@password", SqlDbType.NVarChar).Value = Password;
            command.Parameters.Add("@gender", SqlDbType.NVarChar).Value = Gender;
            command.Parameters.Add("@birthdate", SqlDbType.DateTime).Value = Birthdate;
            command.Parameters.Add("@role", SqlDbType.NVarChar).Value = Role;
            command.Parameters.Add("@status", SqlDbType.NVarChar).Value = Status;
            command.Parameters.Add("@code", SqlDbType.NVarChar).Value = Code;
            command.Parameters.Add("@email", SqlDbType.NVarChar).Value = Email;
            command.Parameters.Add("@created", SqlDbType.DateTime).Value = DateTime.Now;
            if (Image != null)
            {
                using (MemoryStream ms = new MemoryStream())
                {
                    Image.Save(ms, ImageFormat.Png);
                    command.Parameters.Add("@images", System.Data.SqlDbType.Image).Value = ms.ToArray();
                }
            }
            else
                command.Parameters.Add("@images", System.Data.SqlDbType.Image).Value = DBNull.Value;

            if (command.ExecuteNonQuery() == 1)
            {
                database.closeConnection();
                return true;
            }
            database.closeConnection();
            return false;
        }

        #endregion

        #region Get Data

        public static DataTable getUserWithFullName(string fullname)
        {
            Database database = new Database();
            SqlCommand command = new SqlCommand();
            command.Connection = database.getConnection;
            command.CommandText = string.Format("SELECT * FROM getInfoUserWithFullName('%{0}%')", fullname);

            SqlDataAdapter adapter = new SqlDataAdapter(command);
            DataTable table = new DataTable();
            adapter.Fill(table);

            return table;
        }

        public static DataTable getAllUsers()
        {
            Database database = new Database();
            SqlCommand command = new SqlCommand();
            command.Connection = database.getConnection;
            command.CommandText = "SELECT * FROM listUser";

            SqlDataAdapter adapter = new SqlDataAdapter(command);
            DataTable table = new DataTable();
            adapter.Fill(table);

            return table;
        }

        public static DataTable getUserWithID(string id)
        {
            Database database = new Database();
            SqlCommand command = new SqlCommand();
            command.Connection = database.getConnection;
            command.CommandText = string.Format("SELECT * FROM getInfoUserWithID({0})", id);

            SqlDataAdapter adapter = new SqlDataAdapter(command);
            DataTable table = new DataTable();
            adapter.Fill(table);

            return table;
        }

        public static DataTable getUserWithCode(string code)
        {
            Database database = new Database();
            SqlCommand command = new SqlCommand();
            command.Connection = database.getConnection;
            command.CommandText = string.Format("SELECT * FROM users WHERE code = @code");
            command.Parameters.Add("@code", SqlDbType.NVarChar).Value = code;
            SqlDataAdapter adapter = new SqlDataAdapter(command);
            DataTable table = new DataTable();
            adapter.Fill(table);

            return table;
        }

        #endregion

        #region Delete
        public static bool deleteUserWithID(string id)
        {
            Database database = new Database();
            database.openConnection();
            SqlCommand command = new SqlCommand();
            command.Connection = database.getConnection;
            command.CommandText = "EXECUTE deleteUserWithID @id";
            command.Parameters.Add("@id", SqlDbType.VarChar).Value = id;
            DataTable table = new DataTable();
            SqlDataAdapter adapter = new SqlDataAdapter(command);
            adapter.Fill(table);
            if (int.Parse(table.Rows[0]["rowsDelete"].ToString()) > 0)
                return true;

            return false;
        }

        #endregion

        #region Update

        public static bool isUpdatePassword(string UserID, string newPassword)
        {
            database.openConnection();
            SqlCommand command = new SqlCommand();
            command.Connection = database.getConnection;
            command.CommandText = "UPDATE users SET password = @newPass WHERE id = @userID";
            command.Parameters.Add("@newPass", System.Data.SqlDbType.NVarChar).Value = newPassword;
            command.Parameters.Add("@userID", System.Data.SqlDbType.NVarChar).Value = UserID;

            if (command.ExecuteNonQuery() == 1)
                return true;

            return false;
        }

        public bool isUpdateUser(string UserID)
        {
            database.openConnection();
            SqlCommand command = new SqlCommand();
            command.Connection = database.getConnection;
            command.CommandText = "UPDATE users SET fullname = @fullname, username = @username, password = @password, gender = @gender, " +
                "birthdate = @birthdate, role = @role, status = @status, images = @images, modified_time = @modified WHERE id = @userID";


            command.Parameters.Add("@fullname", System.Data.SqlDbType.NVarChar).Value = Fullname;
            command.Parameters.Add("@username", System.Data.SqlDbType.NVarChar).Value = Username;
            command.Parameters.Add("@password", System.Data.SqlDbType.NVarChar).Value = Password;
            command.Parameters.Add("@gender", System.Data.SqlDbType.NVarChar).Value = Gender;
            command.Parameters.Add("@birthdate", System.Data.SqlDbType.DateTime).Value = Birthdate;
            command.Parameters.Add("@role", System.Data.SqlDbType.NVarChar).Value = Role.ToString();
            command.Parameters.Add("@status", System.Data.SqlDbType.NVarChar).Value = Status;

            if (Image != null)
            {
                using (MemoryStream ms = new MemoryStream())
                {
                    Image.Save(ms, ImageFormat.Png);
                    command.Parameters.Add("@images", System.Data.SqlDbType.Image).Value = ms.ToArray();
                }
            }
            else
                command.Parameters.Add("@images", System.Data.SqlDbType.Image).Value = DBNull.Value;

            command.Parameters.Add("@modified", SqlDbType.DateTime).Value = DateTime.Now;
            command.Parameters.Add("@userID", SqlDbType.Int).Value = int.Parse(UserID);

            if (command.ExecuteNonQuery() == 1)
                return true;

            return false;
        }

        public static bool isEditMyAccount(string fullname, string password, Image images, string userCode)
        {
            database.openConnection();
            SqlCommand command = new SqlCommand();
            command.Connection = database.getConnection;
            command.CommandText = "UPDATE users SET fullname = @fullname, password = @password, images = @images, modified_time = @modified WHERE code = @code";


            command.Parameters.Add("@fullname", System.Data.SqlDbType.NVarChar).Value = fullname;
            command.Parameters.Add("@password", System.Data.SqlDbType.NVarChar).Value = password;
            command.Parameters.Add("@code", System.Data.SqlDbType.NVarChar).Value = userCode;


            if (images != null)
            {
                using (MemoryStream ms = new MemoryStream())
                {
                    images.Save(ms, ImageFormat.Png);
                    command.Parameters.Add("@images", System.Data.SqlDbType.Image).Value = ms.ToArray();
                }
            }
            else
                command.Parameters.Add("@images", System.Data.SqlDbType.Image).Value = DBNull.Value;

            command.Parameters.Add("@modified", SqlDbType.DateTime).Value = DateTime.Now;

            if (command.ExecuteNonQuery() == 1)
                return true;

            return false;
        }

        #endregion

        public static string getUserIDFromEmail(string email)
        {
            SqlCommand command = new SqlCommand();
            command.Connection = database.getConnection;
            command.CommandText = string.Format("SELECT id FROM users WHERE email = @email");
            command.Parameters.Add("@email", SqlDbType.NVarChar).Value = email;

            SqlDataAdapter adapter = new SqlDataAdapter(command);
            DataTable table = new DataTable();
            adapter.Fill(table);

            if (table.Rows.Count <= 0)
                return string.Empty;
            return table.Rows[0]["id"].ToString();
        }
    }
}
