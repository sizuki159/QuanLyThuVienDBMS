﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Net.Mail;
using System.Net;
using System.Data.SqlClient;
using System.Data;

namespace QuanLyThuVien_CuoiKyWindows_NguyenThanhTrung_19110304.Classes
{
    public class TrungHelper
    {
        public static void setDefaultDataGridView(DataGridView dgv)
        {
            dgv.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            dgv.AllowUserToAddRows = false;
            dgv.AllowUserToDeleteRows = false;
            dgv.ReadOnly = true;
        }

        public static bool boolSendEmailRecoverAccount(string emailAddressReceive, string userID)
        {
            string Email = Classes.Settings.getValue(Classes.Settings.KeyGmail);
            //string Password = "vgdyrvwruyhwjtdc";
            string Password = Classes.Settings.getValue(Classes.Settings.KeyPassEmail);

            string codeRecovery = RandomString(6);
            DateTime expiry_date = DateTime.Now.AddMinutes(15);

            Database database = new Database();
            database.openConnection();

            SqlCommand command = new SqlCommand();
            command.Connection = database.getConnection;
            command.CommandText = "INSERT INTO recover_code VALUES(@userID, @codeRecover, @expiryDate, @status)";
            command.Parameters.Add("@userID", System.Data.SqlDbType.Int).Value = Convert.ToInt32(userID);
            command.Parameters.Add("@codeRecover", System.Data.SqlDbType.NVarChar).Value = codeRecovery;
            command.Parameters.Add("@expiryDate", System.Data.SqlDbType.DateTime).Value = expiry_date;
            command.Parameters.Add("@status", System.Data.SqlDbType.NVarChar).Value = "pending";


            string formBodyEmail = string.Format(@"Chúng tôi nhận được yêu cầu khôi phục mật khẩu tài khoản của bạn trên hệ thống thư viện của trường đại học Sư Phạm Kỹ Thuật. Mã khôi phục là: {0} - Mã có hiệu lực đến: {1}", codeRecovery, expiry_date.ToString(@"dd/MM/yyyy hh:mm:ss tt"));
            var client = new SmtpClient("smtp.gmail.com", 587)
            {
                Credentials = new NetworkCredential(Email, Password),
                EnableSsl = true
            };
            try
            {
                client.Send(Email, emailAddressReceive, "Recovery Password Library HCMUTE", formBodyEmail);
                if (command.ExecuteNonQuery() != 1)
                {
                    return false;
                }
            } catch { return false; }
            return true;
        }


        public static bool isCheckCodeAvailable(string code, string userID)
        {
            Database database = new Database();
            database.openConnection();
            SqlCommand command = new SqlCommand();
            command.Connection = database.getConnection;
            command.CommandText = @"SELECT * FROM recover_code WHERE code_recover = @code AND user_id = @userID AND status = 'pending' AND expiry_date > @timeNow
                                    UPDATE recover_code SET status = 'used' WHERE code_recover = @code AND user_id = @userID";
            command.Parameters.Add("@code", System.Data.SqlDbType.NVarChar).Value = code;
            command.Parameters.Add("@userID", System.Data.SqlDbType.NVarChar).Value = userID;
            command.Parameters.Add("@timeNow", System.Data.SqlDbType.DateTime).Value = DateTime.Now;
            SqlDataAdapter adapter = new SqlDataAdapter(command);
            DataTable table = new DataTable();
            adapter.Fill(table);
            database.closeConnection();
            if (table.Rows.Count <= 0)
                return false;
            return true;
        }

        private static Random random = new Random();
        public static string RandomString(int length)
        {
            const string chars = "0123456789";
            return new string(Enumerable.Repeat(chars, length)
              .Select(s => s[random.Next(s.Length)]).ToArray());
        }

    }
}
