﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace QuanLyThuVien_CuoiKyWindows_NguyenThanhTrung_19110304.Forms.BorrowBooks
{
    public partial class MenuBooksForm : Form
    {
        public MenuBooksForm()
        {
            InitializeComponent();

            Classes.TrungHelper.setDefaultDataGridView(dataGridViewListInfoBook);
            dataGridViewListInfoBook.DataSource = Classes.Books.getBooks();
        }

        private void dataGridViewListInfoBook_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            int bookID = int.Parse(dataGridViewListInfoBook.CurrentRow.Cells[0].Value.ToString());
            string bookname = dataGridViewListInfoBook.CurrentRow.Cells[1].Value.ToString();
            string authorname = dataGridViewListInfoBook.CurrentRow.Cells[2].Value.ToString();
            string typename = dataGridViewListInfoBook.CurrentRow.Cells[3].Value.ToString();
            string price = dataGridViewListInfoBook.CurrentRow.Cells[4].Value.ToString();
            string quantity = dataGridViewListInfoBook.CurrentRow.Cells[5].Value.ToString();
            string description = dataGridViewListInfoBook.CurrentRow.Cells[6].Value.ToString();

            Image images;
            try
            {
                Byte[] dataImage = new Byte[0];
                dataImage = (Byte[])dataGridViewListInfoBook.CurrentRow.Cells[8].Value;
                MemoryStream mem = new MemoryStream(dataImage);
                images = Image.FromStream(mem);
            }
            catch
            {
                images = null;
            }

            BookInfoForm bookInfoForm = new BookInfoForm(bookID, bookname, typename, authorname, price, quantity, description, images);
            bookInfoForm.ShowDialog();
            dataGridViewListInfoBook.DataSource = Classes.Books.getBooks();

        }
    }
}
