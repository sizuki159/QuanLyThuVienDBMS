﻿
namespace QuanLyThuVien_CuoiKyWindows_NguyenThanhTrung_19110304.Forms.BorrowBooks
{
    partial class ViewListBookBorrowingForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(ViewListBookBorrowingForm));
            this.rtbDescription = new System.Windows.Forms.RichTextBox();
            this.txbAuthorName = new System.Windows.Forms.TextBox();
            this.txbName = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.pictureBoxBookPreview = new System.Windows.Forms.PictureBox();
            this.label8 = new System.Windows.Forms.Label();
            this.panelInfoBook = new System.Windows.Forms.Panel();
            this.panel1 = new System.Windows.Forms.Panel();
            this.dataGridViewListInfoBook = new System.Windows.Forms.DataGridView();
            this.panelDvBooks = new System.Windows.Forms.Panel();
            this.btnRefresh = new System.Windows.Forms.Button();
            this.txbBookName = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.panelSearch = new System.Windows.Forms.Panel();
            this.labelTitle = new System.Windows.Forms.Label();
            this.pictureBoxTitle = new System.Windows.Forms.PictureBox();
            this.panelTitle = new System.Windows.Forms.Panel();
            this.labelStatus = new System.Windows.Forms.Label();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.btnAction = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxBookPreview)).BeginInit();
            this.panelInfoBook.SuspendLayout();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewListInfoBook)).BeginInit();
            this.panelDvBooks.SuspendLayout();
            this.panelSearch.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxTitle)).BeginInit();
            this.panelTitle.SuspendLayout();
            this.SuspendLayout();
            // 
            // rtbDescription
            // 
            this.rtbDescription.Location = new System.Drawing.Point(793, 6);
            this.rtbDescription.Name = "rtbDescription";
            this.rtbDescription.ReadOnly = true;
            this.rtbDescription.Size = new System.Drawing.Size(471, 256);
            this.rtbDescription.TabIndex = 13;
            this.rtbDescription.Text = "";
            // 
            // txbAuthorName
            // 
            this.txbAuthorName.Location = new System.Drawing.Point(206, 90);
            this.txbAuthorName.Name = "txbAuthorName";
            this.txbAuthorName.ReadOnly = true;
            this.txbAuthorName.Size = new System.Drawing.Size(364, 26);
            this.txbAuthorName.TabIndex = 10;
            // 
            // txbName
            // 
            this.txbName.Location = new System.Drawing.Point(206, 29);
            this.txbName.Name = "txbName";
            this.txbName.ReadOnly = true;
            this.txbName.Size = new System.Drawing.Size(364, 26);
            this.txbName.TabIndex = 8;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(655, 30);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(130, 20);
            this.label7.TabIndex = 5;
            this.label7.Text = "Book Description";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(85, 96);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(103, 20);
            this.label3.TabIndex = 1;
            this.label3.Text = "Author Name";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(85, 35);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(92, 20);
            this.label2.TabIndex = 0;
            this.label2.Text = "Book Name";
            // 
            // pictureBoxBookPreview
            // 
            this.pictureBoxBookPreview.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pictureBoxBookPreview.Location = new System.Drawing.Point(0, 0);
            this.pictureBoxBookPreview.Name = "pictureBoxBookPreview";
            this.pictureBoxBookPreview.Size = new System.Drawing.Size(309, 432);
            this.pictureBoxBookPreview.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBoxBookPreview.TabIndex = 12;
            this.pictureBoxBookPreview.TabStop = false;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(85, 242);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(56, 20);
            this.label8.TabIndex = 19;
            this.label8.Text = "Status";
            // 
            // panelInfoBook
            // 
            this.panelInfoBook.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.panelInfoBook.Controls.Add(this.btnAction);
            this.panelInfoBook.Controls.Add(this.labelStatus);
            this.panelInfoBook.Controls.Add(this.label8);
            this.panelInfoBook.Controls.Add(this.panel1);
            this.panelInfoBook.Controls.Add(this.rtbDescription);
            this.panelInfoBook.Controls.Add(this.txbAuthorName);
            this.panelInfoBook.Controls.Add(this.txbName);
            this.panelInfoBook.Controls.Add(this.label7);
            this.panelInfoBook.Controls.Add(this.label3);
            this.panelInfoBook.Controls.Add(this.label2);
            this.panelInfoBook.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panelInfoBook.Location = new System.Drawing.Point(0, 618);
            this.panelInfoBook.Name = "panelInfoBook";
            this.panelInfoBook.Size = new System.Drawing.Size(1710, 432);
            this.panelInfoBook.TabIndex = 7;
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.pictureBoxBookPreview);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Right;
            this.panel1.Location = new System.Drawing.Point(1401, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(309, 432);
            this.panel1.TabIndex = 15;
            // 
            // dataGridViewListInfoBook
            // 
            this.dataGridViewListInfoBook.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dataGridViewListInfoBook.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewListInfoBook.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dataGridViewListInfoBook.Location = new System.Drawing.Point(0, 0);
            this.dataGridViewListInfoBook.Name = "dataGridViewListInfoBook";
            this.dataGridViewListInfoBook.RowHeadersWidth = 62;
            this.dataGridViewListInfoBook.RowTemplate.Height = 28;
            this.dataGridViewListInfoBook.Size = new System.Drawing.Size(1710, 388);
            this.dataGridViewListInfoBook.TabIndex = 0;
            this.dataGridViewListInfoBook.CellDoubleClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridViewListInfoBook_CellDoubleClick);
            // 
            // panelDvBooks
            // 
            this.panelDvBooks.Controls.Add(this.dataGridViewListInfoBook);
            this.panelDvBooks.Dock = System.Windows.Forms.DockStyle.Top;
            this.panelDvBooks.Location = new System.Drawing.Point(0, 230);
            this.panelDvBooks.Name = "panelDvBooks";
            this.panelDvBooks.Size = new System.Drawing.Size(1710, 388);
            this.panelDvBooks.TabIndex = 6;
            // 
            // btnRefresh
            // 
            this.btnRefresh.Location = new System.Drawing.Point(774, 30);
            this.btnRefresh.Name = "btnRefresh";
            this.btnRefresh.Size = new System.Drawing.Size(126, 41);
            this.btnRefresh.TabIndex = 2;
            this.btnRefresh.Text = "Refresh";
            this.btnRefresh.UseVisualStyleBackColor = true;
            // 
            // txbBookName
            // 
            this.txbBookName.Location = new System.Drawing.Point(482, 36);
            this.txbBookName.Name = "txbBookName";
            this.txbBookName.Size = new System.Drawing.Size(237, 26);
            this.txbBookName.TabIndex = 1;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(336, 36);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(92, 20);
            this.label1.TabIndex = 0;
            this.label1.Text = "Book Name";
            // 
            // panelSearch
            // 
            this.panelSearch.Controls.Add(this.btnRefresh);
            this.panelSearch.Controls.Add(this.txbBookName);
            this.panelSearch.Controls.Add(this.label1);
            this.panelSearch.Dock = System.Windows.Forms.DockStyle.Top;
            this.panelSearch.Location = new System.Drawing.Point(0, 121);
            this.panelSearch.Name = "panelSearch";
            this.panelSearch.Size = new System.Drawing.Size(1710, 109);
            this.panelSearch.TabIndex = 5;
            // 
            // labelTitle
            // 
            this.labelTitle.AutoSize = true;
            this.labelTitle.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelTitle.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.labelTitle.Location = new System.Drawing.Point(618, 49);
            this.labelTitle.Name = "labelTitle";
            this.labelTitle.Size = new System.Drawing.Size(292, 29);
            this.labelTitle.TabIndex = 1;
            this.labelTitle.Text = "My History Book Borrow";
            // 
            // pictureBoxTitle
            // 
            this.pictureBoxTitle.Image = ((System.Drawing.Image)(resources.GetObject("pictureBoxTitle.Image")));
            this.pictureBoxTitle.Location = new System.Drawing.Point(482, 12);
            this.pictureBoxTitle.Name = "pictureBoxTitle";
            this.pictureBoxTitle.Size = new System.Drawing.Size(88, 106);
            this.pictureBoxTitle.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBoxTitle.TabIndex = 0;
            this.pictureBoxTitle.TabStop = false;
            // 
            // panelTitle
            // 
            this.panelTitle.BackColor = System.Drawing.Color.White;
            this.panelTitle.Controls.Add(this.labelTitle);
            this.panelTitle.Controls.Add(this.pictureBoxTitle);
            this.panelTitle.Dock = System.Windows.Forms.DockStyle.Top;
            this.panelTitle.Location = new System.Drawing.Point(0, 0);
            this.panelTitle.Name = "panelTitle";
            this.panelTitle.Size = new System.Drawing.Size(1710, 121);
            this.panelTitle.TabIndex = 4;
            // 
            // labelStatus
            // 
            this.labelStatus.AutoSize = true;
            this.labelStatus.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelStatus.Location = new System.Drawing.Point(201, 237);
            this.labelStatus.Name = "labelStatus";
            this.labelStatus.Size = new System.Drawing.Size(74, 25);
            this.labelStatus.TabIndex = 20;
            this.labelStatus.Text = "Status";
            // 
            // timer1
            // 
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // btnAction
            // 
            this.btnAction.Location = new System.Drawing.Point(353, 327);
            this.btnAction.Name = "btnAction";
            this.btnAction.Size = new System.Drawing.Size(235, 64);
            this.btnAction.TabIndex = 21;
            this.btnAction.Text = "btnAction";
            this.btnAction.UseVisualStyleBackColor = true;
            this.btnAction.Click += new System.EventHandler(this.btnAction_Click);
            // 
            // ViewListBookBorrowingForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1710, 1050);
            this.Controls.Add(this.panelInfoBook);
            this.Controls.Add(this.panelDvBooks);
            this.Controls.Add(this.panelSearch);
            this.Controls.Add(this.panelTitle);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Name = "ViewListBookBorrowingForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "ViewListBookBorrowingForm";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.Load += new System.EventHandler(this.ViewListBookBorrowingForm_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxBookPreview)).EndInit();
            this.panelInfoBook.ResumeLayout(false);
            this.panelInfoBook.PerformLayout();
            this.panel1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewListInfoBook)).EndInit();
            this.panelDvBooks.ResumeLayout(false);
            this.panelSearch.ResumeLayout(false);
            this.panelSearch.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxTitle)).EndInit();
            this.panelTitle.ResumeLayout(false);
            this.panelTitle.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.RichTextBox rtbDescription;
        private System.Windows.Forms.TextBox txbAuthorName;
        private System.Windows.Forms.TextBox txbName;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.PictureBox pictureBoxBookPreview;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Panel panelInfoBook;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.DataGridView dataGridViewListInfoBook;
        private System.Windows.Forms.Panel panelDvBooks;
        private System.Windows.Forms.Button btnRefresh;
        private System.Windows.Forms.TextBox txbBookName;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Panel panelSearch;
        private System.Windows.Forms.Label labelTitle;
        private System.Windows.Forms.PictureBox pictureBoxTitle;
        private System.Windows.Forms.Panel panelTitle;
        private System.Windows.Forms.Label labelStatus;
        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.Button btnAction;
    }
}