﻿
namespace QuanLyThuVien_CuoiKyWindows_NguyenThanhTrung_19110304.Forms
{
    partial class Settings
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Settings));
            this.pictureBoxTitle = new System.Windows.Forms.PictureBox();
            this.labelTitle = new System.Windows.Forms.Label();
            this.panelMiddle = new System.Windows.Forms.Panel();
            this.panel1 = new System.Windows.Forms.Panel();
            this.numericUpDownClose = new System.Windows.Forms.NumericUpDown();
            this.numericUpDownOpen = new System.Windows.Forms.NumericUpDown();
            this.btnSaveTime = new System.Windows.Forms.Button();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.panelGmail = new System.Windows.Forms.Panel();
            this.btnSaveGmail = new System.Windows.Forms.Button();
            this.txbGmail = new System.Windows.Forms.TextBox();
            this.txbPassGmail = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.panelTop = new System.Windows.Forms.Panel();
            this.panelStaff = new System.Windows.Forms.Panel();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxTitle)).BeginInit();
            this.panelMiddle.SuspendLayout();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownClose)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownOpen)).BeginInit();
            this.panelGmail.SuspendLayout();
            this.panelTop.SuspendLayout();
            this.SuspendLayout();
            // 
            // pictureBoxTitle
            // 
            this.pictureBoxTitle.Image = ((System.Drawing.Image)(resources.GetObject("pictureBoxTitle.Image")));
            this.pictureBoxTitle.Location = new System.Drawing.Point(183, 0);
            this.pictureBoxTitle.Name = "pictureBoxTitle";
            this.pictureBoxTitle.Size = new System.Drawing.Size(59, 53);
            this.pictureBoxTitle.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBoxTitle.TabIndex = 0;
            this.pictureBoxTitle.TabStop = false;
            // 
            // labelTitle
            // 
            this.labelTitle.AutoSize = true;
            this.labelTitle.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelTitle.Location = new System.Drawing.Point(248, 9);
            this.labelTitle.Name = "labelTitle";
            this.labelTitle.Size = new System.Drawing.Size(403, 29);
            this.labelTitle.TabIndex = 1;
            this.labelTitle.Text = "Settings System Library HCMUTE";
            // 
            // panelMiddle
            // 
            this.panelMiddle.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.panelMiddle.Controls.Add(this.panel1);
            this.panelMiddle.Controls.Add(this.label3);
            this.panelMiddle.Controls.Add(this.panelGmail);
            this.panelMiddle.Dock = System.Windows.Forms.DockStyle.Top;
            this.panelMiddle.Location = new System.Drawing.Point(0, 65);
            this.panelMiddle.Name = "panelMiddle";
            this.panelMiddle.Size = new System.Drawing.Size(895, 548);
            this.panelMiddle.TabIndex = 5;
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.numericUpDownClose);
            this.panel1.Controls.Add(this.numericUpDownOpen);
            this.panel1.Controls.Add(this.btnSaveTime);
            this.panel1.Controls.Add(this.label6);
            this.panel1.Controls.Add(this.label5);
            this.panel1.Controls.Add(this.label4);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel1.Location = new System.Drawing.Point(0, 136);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(895, 155);
            this.panel1.TabIndex = 6;
            // 
            // numericUpDownClose
            // 
            this.numericUpDownClose.Location = new System.Drawing.Point(425, 69);
            this.numericUpDownClose.Maximum = new decimal(new int[] {
            20,
            0,
            0,
            0});
            this.numericUpDownClose.Minimum = new decimal(new int[] {
            8,
            0,
            0,
            0});
            this.numericUpDownClose.Name = "numericUpDownClose";
            this.numericUpDownClose.Size = new System.Drawing.Size(120, 26);
            this.numericUpDownClose.TabIndex = 7;
            this.numericUpDownClose.Value = new decimal(new int[] {
            20,
            0,
            0,
            0});
            // 
            // numericUpDownOpen
            // 
            this.numericUpDownOpen.Location = new System.Drawing.Point(170, 69);
            this.numericUpDownOpen.Maximum = new decimal(new int[] {
            19,
            0,
            0,
            0});
            this.numericUpDownOpen.Minimum = new decimal(new int[] {
            7,
            0,
            0,
            0});
            this.numericUpDownOpen.Name = "numericUpDownOpen";
            this.numericUpDownOpen.Size = new System.Drawing.Size(120, 26);
            this.numericUpDownOpen.TabIndex = 6;
            this.numericUpDownOpen.Value = new decimal(new int[] {
            7,
            0,
            0,
            0});
            // 
            // btnSaveTime
            // 
            this.btnSaveTime.Location = new System.Drawing.Point(730, 56);
            this.btnSaveTime.Name = "btnSaveTime";
            this.btnSaveTime.Size = new System.Drawing.Size(115, 50);
            this.btnSaveTime.TabIndex = 5;
            this.btnSaveTime.Text = "Save Time";
            this.btnSaveTime.UseVisualStyleBackColor = true;
            this.btnSaveTime.Click += new System.EventHandler(this.btnSaveTime_Click);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(334, 75);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(42, 20);
            this.label6.TabIndex = 4;
            this.label6.Text = "Đến";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(20, 75);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(88, 20);
            this.label5.TabIndex = 3;
            this.label5.Text = "Mở cửa từ";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(282, 19);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(310, 25);
            this.label4.TabIndex = 0;
            this.label4.Text = "Thời gian làm việc của thư viện";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(71, 185);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(0, 20);
            this.label3.TabIndex = 5;
            // 
            // panelGmail
            // 
            this.panelGmail.Controls.Add(this.btnSaveGmail);
            this.panelGmail.Controls.Add(this.txbGmail);
            this.panelGmail.Controls.Add(this.txbPassGmail);
            this.panelGmail.Controls.Add(this.label1);
            this.panelGmail.Controls.Add(this.label2);
            this.panelGmail.Dock = System.Windows.Forms.DockStyle.Top;
            this.panelGmail.Location = new System.Drawing.Point(0, 0);
            this.panelGmail.Name = "panelGmail";
            this.panelGmail.Size = new System.Drawing.Size(895, 136);
            this.panelGmail.TabIndex = 4;
            // 
            // btnSaveGmail
            // 
            this.btnSaveGmail.Location = new System.Drawing.Point(730, 40);
            this.btnSaveGmail.Name = "btnSaveGmail";
            this.btnSaveGmail.Size = new System.Drawing.Size(115, 50);
            this.btnSaveGmail.TabIndex = 4;
            this.btnSaveGmail.Text = "Save Gmail";
            this.btnSaveGmail.UseVisualStyleBackColor = true;
            this.btnSaveGmail.Click += new System.EventHandler(this.btnSaveGmail_Click);
            // 
            // txbGmail
            // 
            this.txbGmail.Location = new System.Drawing.Point(278, 22);
            this.txbGmail.Name = "txbGmail";
            this.txbGmail.Size = new System.Drawing.Size(411, 26);
            this.txbGmail.TabIndex = 2;
            // 
            // txbPassGmail
            // 
            this.txbPassGmail.Location = new System.Drawing.Point(278, 86);
            this.txbPassGmail.Name = "txbPassGmail";
            this.txbPassGmail.Size = new System.Drawing.Size(411, 26);
            this.txbPassGmail.TabIndex = 3;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(71, 28);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(126, 20);
            this.label1.TabIndex = 0;
            this.label1.Text = "Gmail Account";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(71, 89);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(99, 20);
            this.label2.TabIndex = 1;
            this.label2.Text = "Pass Gmail";
            // 
            // panelTop
            // 
            this.panelTop.BackColor = System.Drawing.Color.Wheat;
            this.panelTop.Controls.Add(this.labelTitle);
            this.panelTop.Controls.Add(this.pictureBoxTitle);
            this.panelTop.Dock = System.Windows.Forms.DockStyle.Top;
            this.panelTop.Location = new System.Drawing.Point(0, 0);
            this.panelTop.Name = "panelTop";
            this.panelTop.Size = new System.Drawing.Size(895, 65);
            this.panelTop.TabIndex = 4;
            // 
            // panelStaff
            // 
            this.panelStaff.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panelStaff.Location = new System.Drawing.Point(0, 613);
            this.panelStaff.Name = "panelStaff";
            this.panelStaff.Size = new System.Drawing.Size(895, 238);
            this.panelStaff.TabIndex = 6;
            // 
            // Settings
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(895, 851);
            this.Controls.Add(this.panelStaff);
            this.Controls.Add(this.panelMiddle);
            this.Controls.Add(this.panelTop);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Name = "Settings";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Settings";
            this.Load += new System.EventHandler(this.Settings_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxTitle)).EndInit();
            this.panelMiddle.ResumeLayout(false);
            this.panelMiddle.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownClose)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownOpen)).EndInit();
            this.panelGmail.ResumeLayout(false);
            this.panelGmail.PerformLayout();
            this.panelTop.ResumeLayout(false);
            this.panelTop.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.PictureBox pictureBoxTitle;
        private System.Windows.Forms.Label labelTitle;
        private System.Windows.Forms.Panel panelMiddle;
        private System.Windows.Forms.Panel panelTop;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txbPassGmail;
        private System.Windows.Forms.TextBox txbGmail;
        private System.Windows.Forms.Panel panelGmail;
        private System.Windows.Forms.Button btnSaveGmail;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Panel panelStaff;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Button btnSaveTime;
        private System.Windows.Forms.NumericUpDown numericUpDownOpen;
        private System.Windows.Forms.NumericUpDown numericUpDownClose;
    }
}