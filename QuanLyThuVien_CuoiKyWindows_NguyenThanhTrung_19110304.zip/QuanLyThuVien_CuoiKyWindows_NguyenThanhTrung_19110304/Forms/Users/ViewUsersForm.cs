﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace QuanLyThuVien_CuoiKyWindows_NguyenThanhTrung_19110304.Forms.Users
{
    public partial class ViewUsersForm : Form
    {
        static int userID = -1;
        public ViewUsersForm()
        {
            InitializeComponent();
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void pictureBoxUploadImage_Click(object sender, EventArgs e)
        {
            OpenFileDialog open = new OpenFileDialog();
            // image filters  
            open.Filter = "Image Files(*.jpg; *.png; *.jpeg; *.gif; *.bmp)|*.jpg; *.png; *.jpeg; *.gif; *.bmp";
            if (open.ShowDialog() == DialogResult.OK)
            {
                // display image in picture box  
                pictureBoxPreview.Image = new Bitmap(open.FileName);
            }
        }

        private void ViewUsersForm_Load(object sender, EventArgs e)
        {
            panelInfoUser.Visible = false;

            Classes.TrungHelper.setDefaultDataGridView(dataGridViewListInfoUser);
            dataGridViewListInfoUser.DataSource = Classes.Users.getAllUsers();
        }

        private void dataGridViewListInfoUser_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            if (dataGridViewListInfoUser.CurrentRow.Cells[0].Value != null)
                userID = int.Parse(dataGridViewListInfoUser.Rows[e.RowIndex].Cells[0].Value.ToString());
            else
            {
                MessageBox.Show("Lỗi không convert được ID User", "Action Fail", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            panelInfoUser.Visible = true;
            DataTable infoUser = Classes.Users.getUserWithID(userID.ToString());
            txbFullname.Text = infoUser.Rows[0]["fullname"].ToString();
            txbUsername.Text = infoUser.Rows[0]["username"].ToString();
            txbPassword.Text = infoUser.Rows[0]["password"].ToString();
            txbCode.Text = infoUser.Rows[0]["code"].ToString();
            txbEmail.Text = infoUser.Rows[0]["email"].ToString();


            if (infoUser.Rows[0]["gender"].ToString().Trim().ToLower() == "male")
                rbtnMale.Checked = true;
            else
                rbtnFemale.Checked = true;

            try
            {
                DateTime birthdate = DateTime.Parse(infoUser.Rows[0]["birthdate"].ToString());
                dtpBirthdate.Value = birthdate;
            } catch { }


            if (infoUser.Rows[0]["role"].ToString() == Classes.Users.User_Role.Student.ToString())
                rbtnStudent.Checked = true;
            else if (infoUser.Rows[0]["role"].ToString() == Classes.Users.User_Role.Teacher.ToString())
                rbtnTeacher.Checked = true;

            try
            {
                Byte[] dataImage = new Byte[0];
                dataImage = (Byte[])(infoUser.Rows[0]["images"]);
                MemoryStream mem = new MemoryStream(dataImage);
                pictureBoxPreview.Image = Image.FromStream(mem);
            }
            catch
            {
                pictureBoxPreview.Image = null;
            }
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            DialogResult questionDelete = MessageBox.Show("Are you sure you want to delete?", "Question Action", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (questionDelete == DialogResult.Yes)
            {
                bool isDelete = Classes.Users.deleteUserWithID(userID.ToString());
                if (isDelete)
                {
                    MessageBox.Show("Delete user success", "Action Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    dataGridViewListInfoUser.DataSource = Classes.Users.getAllUsers();
                    panelInfoUser.Visible = false;
                }
                else
                    MessageBox.Show("Delete user fail", "Action Fail", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {
            DialogResult questionDelete = MessageBox.Show("Are you sure you want to update it?", "Question Action", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (questionDelete == DialogResult.No)
                return;

            if (!validateForm())
            {
                MessageBox.Show("Please Enter All Fields. Can not empty any fields", "Validate Form Fail", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            Classes.Users user = new Classes.Users(txbUsername.Text, txbPassword.Text);
            user.Fullname = txbFullname.Text;
            user.Gender = "Female";
            if (rbtnMale.Checked)
                user.Gender = "Male";
            user.Birthdate = dtpBirthdate.Value;
            if (rbtnStudent.Checked)
                user.Role = Classes.Users.User_Role.Student;
            else if (rbtnTeacher.Checked)
                user.Role = Classes.Users.User_Role.Teacher;
            user.Code = txbCode.Text;
            user.Email = txbEmail.Text;
            user.Image = pictureBoxPreview.Image;

            if (user.isUpdateUser(userID.ToString()))
            {
                MessageBox.Show("Update User Success", "Action Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                dataGridViewListInfoUser.DataSource = Classes.Users.getAllUsers();
                panelInfoUser.Visible = false;
            }
            else
                MessageBox.Show("Update User Error", "Action Fail", MessageBoxButtons.OK, MessageBoxIcon.Error);
        }

        private bool validateForm()
        {
            if (string.IsNullOrEmpty(txbFullname.Text) || string.IsNullOrEmpty(txbUsername.Text) || string.IsNullOrEmpty(txbPassword.Text)
                    || string.IsNullOrEmpty(txbCode.Text) || (!rbtnFemale.Checked && !rbtnMale.Checked) || (!rbtnStudent.Checked && !rbtnTeacher.Checked))
                return false;
            return true;
        }

        private void txbFullnameSearch_TextChanged(object sender, EventArgs e)
        {
            string userFullname = txbFullnameSearch.Text;
            dataGridViewListInfoUser.DataSource = Classes.Users.getUserWithFullName(userFullname);
        }

        private void btnRefresh_Click(object sender, EventArgs e)
        {
            txbFullnameSearch.Text = string.Empty;
        }
    }
}