﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace QuanLyThuVien_CuoiKyWindows_NguyenThanhTrung_19110304.Forms.Books
{
    public partial class AddBookTypeForm : Form
    {
        public AddBookTypeForm()
        {
            InitializeComponent();
        }

        static int bookTypeID;

        private void AddBookTypeForm_Load(object sender, EventArgs e)
        {
            Classes.TrungHelper.setDefaultDataGridView(dataGridViewListBookType);
            resetForm();
        }

        private void dataGridViewListBookType_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            panelContentDelete.Visible = false;
            rbtnDeleteAllBook.Checked = true;
            try
            {
                if (dataGridViewListBookType.CurrentRow.Cells[0].Value != null)
                    bookTypeID = int.Parse(dataGridViewListBookType.CurrentRow.Cells[0].Value.ToString());
                else
                {
                    MessageBox.Show("Lỗi không convert được ID loại sách", "Action Fail", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }
                DataTable infoBookType = Classes.Books.Book_Type.getBookTypeWithID(bookTypeID.ToString());
                txbName.Text = infoBookType.Rows[0]["typename"].ToString();

                string status = infoBookType.Rows[0]["status"].ToString();
                if (status == Classes.Books.Book_Type.BookType_Status.Active.ToString())
                    rbtnStatusActive.Checked = true;
                else if (status == Classes.Books.Book_Type.BookType_Status.Inactive.ToString())
                    rbtnStatusInactive.Checked = true;

                btnRemove.Enabled = true;
                btnUpdate.Enabled = true;
                btnAdd.Enabled = false;

            }
            catch
            {
                btnRemove.Enabled = false;
                btnUpdate.Enabled = false;
            }
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            Classes.Books.Book_Type bookType = new Classes.Books.Book_Type();
            bookType.Name = txbName.Text;
            if (rbtnStatusActive.Checked)
                bookType.Status = Classes.Books.Book_Type.BookType_Status.Active;
            else if (rbtnStatusInactive.Checked)
                bookType.Status = Classes.Books.Book_Type.BookType_Status.Inactive;
            else
            {
                MessageBox.Show("Please Check Status", "Action Fail", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            if(bookType.isInsert())
            {
                MessageBox.Show("Add Book Type Success", "Action Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                resetForm();
            }
            else
            {
                MessageBox.Show("Add Book Type Fail", "Action Fail", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void txbName_TextChanged(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(txbName.Text))
                btnAdd.Enabled = true;
            else
                btnAdd.Enabled = false;
        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {
            DialogResult questionDelete = MessageBox.Show("Are you sure you want to update it?", "Question Action", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (questionDelete == DialogResult.No)
                return;

            

            Classes.Books.Book_Type bookType = new Classes.Books.Book_Type();
            bookType.Name = txbName.Text;
            if (rbtnStatusActive.Checked)
                bookType.Status = Classes.Books.Book_Type.BookType_Status.Active;
            else if (rbtnStatusInactive.Checked)
                bookType.Status = Classes.Books.Book_Type.BookType_Status.Inactive;

            if(ValidateForm("update"))
            {
                if(bookType.isUpdateBookType(bookTypeID.ToString()))
                {
                    MessageBox.Show("Update Book Type Success", "Action Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    resetForm();
                }
                else
                    MessageBox.Show("Update Book Type Error", "Action Fail", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

        }

        private bool ValidateForm(string operation)
        {
            if (operation == "update")
            {
                if (string.IsNullOrEmpty(txbName.Text))
                    return false;
                return true;
            }
            return false;
        }

        private void btnRemove_Click(object sender, EventArgs e)
        {
            
            int numberBookOfCurrentTypeID = Classes.Books.countBooksWithBookTypeID(bookTypeID.ToString());
            if(numberBookOfCurrentTypeID > 0)
            {
                panelContentDelete.Visible = true;
                labelShowNotification.Text = "Có " + numberBookOfCurrentTypeID.ToString() + " cuốn sách có loại sách\nbạn chuẩn bị xóa.\nBạn có chắc chắn muốn tiếp tục?";
                //if (Classes.Books.deleteAllBookWithBookTypeID(bookTypeID.ToString()))
                //{
                //    MessageBox.Show("Success");
                //}
            }
            else
            {
                panelContentDelete.Visible = false;
                DialogResult questionDelete = MessageBox.Show("Are you sure you want to delete?", "Question Action", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                if (questionDelete == DialogResult.Yes)
                {
                    if(Classes.Books.Book_Type.isDeleteBookTypeWithID(bookTypeID.ToString()))
                    {
                        MessageBox.Show("Delete Book Type Success", "Action Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        resetForm();
                    }
                    else
                        MessageBox.Show("Delete Book Type Error", "Action Fail", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }    
            }    
        }

        private void rbtnDeleteAllBook_CheckedChanged(object sender, EventArgs e)
        {
            if (rbtnDeleteAllBook.Checked)
                comboBoxType.Enabled = false;
            else
            {
                Classes.Books.loadComboBoxBookType(comboBoxType, true, bookTypeID.ToString());
                comboBoxType.Enabled = true;
            }
        }

        private void btnConfirmDelete_Click(object sender, EventArgs e)
        {
            if(rbtnDeleteAllBook.Checked)
            {
                List<string> listBookIDWaitDelete = Classes.Books.getListBookIDWithBookTypeID(bookTypeID.ToString());
                foreach(string bookID in listBookIDWaitDelete)
                {
                    bool isCheckBookBorrowing = Classes.Borrows.isCheckBookBorrowing(bookID.ToString());
                    if (isCheckBookBorrowing)
                    {
                        MessageBox.Show("This book is borrowing by users", "Action Fail", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        return;
                    }
                }

                int numberRowsDeletedHistoryReturned = Classes.Borrows.deleteHistoryBookReturnWithListBookID(listBookIDWaitDelete);


                if (Classes.Books.deleteAllBookWithBookTypeID(bookTypeID.ToString()))
                {
                    if (Classes.Books.Book_Type.isDeleteBookTypeWithID(bookTypeID.ToString()))
                    {
                        MessageBox.Show("Delete "+numberRowsDeletedHistoryReturned.ToString()+" History Borrows Book. Delete Book Type Success", "Action Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        resetForm();
                    }
                }
            }
            else if(rbtnChangeBookType.Checked)
            {
                Classes.Books.Book_Type booktype = comboBoxType.SelectedItem as Classes.Books.Book_Type;
                if (booktype == null)
                {
                    MessageBox.Show("Please Choose Book Type", "Action Fail", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }
                string newBookTypeID = booktype.ID;
                if(Classes.Books.isUpdatBookTypeID(bookTypeID.ToString(), newBookTypeID))
                {
                    if(Classes.Books.Book_Type.isDeleteBookTypeWithID(bookTypeID.ToString()))
                    {
                        MessageBox.Show("Delete Book Type Success", "Action Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        resetForm();
                    }
                }
            }
        }

        private void resetForm()
        {
            dataGridViewListBookType.DataSource = Classes.Books.Book_Type.getBookType();
            bookTypeID = -1;
            txbName.Text = string.Empty;
            panelContentDelete.Visible = false;
            rbtnDeleteAllBook.Checked = true;
            rbtnStatusActive.Checked = true;
            btnAdd.Enabled = false;
            btnRemove.Enabled = false;
            btnUpdate.Enabled = false;
        }
    }
}
