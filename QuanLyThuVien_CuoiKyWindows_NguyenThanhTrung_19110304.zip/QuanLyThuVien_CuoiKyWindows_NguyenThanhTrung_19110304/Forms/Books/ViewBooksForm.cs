﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace QuanLyThuVien_CuoiKyWindows_NguyenThanhTrung_19110304.Forms.Books
{
    public partial class ViewBooksForm : Form
    {
        public ViewBooksForm()
        {
            InitializeComponent();
        }

        public ViewBooksForm(string filterWithBookType)
        {
            InitializeComponent();
        }

        private void ViewBooksForm_Load(object sender, EventArgs e)
        {
            Classes.Books.loadComboBoxBookType(comboBoxType);
            panelInfoBook.Visible = false;

            Classes.TrungHelper.setDefaultDataGridView(dataGridViewListInfoBook);
            dataGridViewListInfoBook.DataSource = Classes.Books.getBooks();
        }

        static int bookID;
        private void dataGridViewListInfoBook_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            try
            {
                if (dataGridViewListInfoBook.CurrentRow.Cells[0].Value != null)
                    bookID = int.Parse(dataGridViewListInfoBook.Rows[e.RowIndex].Cells[0].Value.ToString());
                else
                {
                    MessageBox.Show("Lỗi không convert được ID sách", "Action Fail", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }
                panelInfoBook.Visible = true;
                DataTable infoBook = Classes.Books.getBookWithID(bookID.ToString());
                txbName.Text = infoBook.Rows[0]["bookname"].ToString();
                txbAuthorName.Text = infoBook.Rows[0]["authorname"].ToString();
                //comboBoxType.SelectedIndex = int.Parse(infoBook.Rows[0]["typename"].ToString()) - 1;
                comboBoxType.SelectedItem = infoBook.Rows[0]["typename"].ToString();

                nrudPrice.Value = int.Parse(infoBook.Rows[0]["price"].ToString());
                nrudQuantity.Value = int.Parse(infoBook.Rows[0]["quantity"].ToString());
                rtbDescription.Text = infoBook.Rows[0]["description"].ToString();


                try
                {
                    Byte[] dataImage = new Byte[0];
                    dataImage = (Byte[])(infoBook.Rows[0]["images"]);
                    MemoryStream mem = new MemoryStream(dataImage);
                    pictureBoxBookPreview.Image = Image.FromStream(mem);
                }
                catch
                {
                    pictureBoxBookPreview.Image = null;
                }


                string bookStatus = infoBook.Rows[0]["status"].ToString();
                if (bookStatus == Classes.Books.Book_Status.Active.ToString())
                    rbtnStatusActive.Checked = true;
                else if (bookStatus == Classes.Books.Book_Status.Hiden.ToString())
                    rbtnStatusHiden.Checked = true;
                else if (bookStatus == Classes.Books.Book_Status.Pending.ToString())
                    rbtnStatusPending.Checked = true;
            }
            catch(Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            DialogResult questionDelete = MessageBox.Show("Are you sure you want to delete?", "Question Action", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if(questionDelete == DialogResult.Yes)
            {
                bool isCheckBookBorrowing = Classes.Borrows.isCheckBookBorrowing(bookID.ToString());
                if(isCheckBookBorrowing)
                {
                    MessageBox.Show("This book is borrowing by users", "Action Fail", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }

                int numberRowsDeletedHistoryReturned = Classes.Borrows.deleteHistoryBookReturn(bookID.ToString());
                bool isDelete = Classes.Books.deleteBookWithID(bookID.ToString());
                if (isDelete)
                {
                    MessageBox.Show("Delete "+numberRowsDeletedHistoryReturned.ToString()+" history book return. Delete book success", "Action Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    dataGridViewListInfoBook.DataSource = Classes.Books.getBooks();
                    panelInfoBook.Visible = false;
                }
                else
                    MessageBox.Show("Delete book fail", "Action Fail", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void pictureBoxUploadImage_Click(object sender, EventArgs e)
        {
            OpenFileDialog open = new OpenFileDialog();
            // image filters  
            open.Filter = "Image Files(*.jpg; *.png; *.jpeg; *.gif; *.bmp)|*.jpg; *.png; *.jpeg; *.gif; *.bmp";
            if (open.ShowDialog() == DialogResult.OK)
            {
                // display image in picture box  
                pictureBoxBookPreview.Image = new Bitmap(open.FileName);
            }
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {
            DialogResult questionDelete = MessageBox.Show("Are you sure you want to update it?", "Question Action", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (questionDelete == DialogResult.No)
                return;

            if (!ValidateForm("edit"))
            {
                MessageBox.Show("Data input errors", "Action Fail", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            Classes.Books book = new Classes.Books();
            book.Name = txbName.Text;
            book.AuthorName = txbAuthorName.Text;
            book.BookType = Convert.ToInt32((comboBoxType.SelectedItem as Classes.Books.Book_Type).ID);
            book.Price = (float)nrudPrice.Value;
            book.Quantity = (int)nrudQuantity.Value;
            book.Description = rtbDescription.Text;

            if (rbtnStatusActive.Checked)
                book.Status = Classes.Books.Book_Status.Active;
            else if (rbtnStatusHiden.Checked)
                book.Status = Classes.Books.Book_Status.Hiden;
            else if (rbtnStatusPending.Checked)
                book.Status = Classes.Books.Book_Status.Pending;

            book.Image = pictureBoxBookPreview.Image;

            if(book.isUpdateBook(bookID.ToString()))
            {
                MessageBox.Show("Update Book Success", "Action Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                dataGridViewListInfoBook.DataSource = Classes.Books.getBooks();
                panelInfoBook.Visible = false;
            }
            else
                MessageBox.Show("Update Book Error", "Action Fail", MessageBoxButtons.OK, MessageBoxIcon.Error);
        }

        private bool ValidateForm(string operation)
        {
            if (operation == "edit")
            {
                if (string.IsNullOrEmpty(txbName.Text) || string.IsNullOrEmpty(txbAuthorName.Text)
                                        || string.IsNullOrEmpty(rtbDescription.Text))
                    return false;
                return true;
            }
            return false;
        }

        private void txbBookName_TextChanged(object sender, EventArgs e)
        {
            string bookName = txbBookName.Text;
            dataGridViewListInfoBook.SelectionMode = DataGridViewSelectionMode.FullRowSelect;

            //foreach (DataGridViewRow row in dataGridViewListInfoBook.Rows)
            //{
            //    string a = row.Cells[1].Value.ToString();
            //    if (a.Contains(bookName))
            //    {
            //        row.Selected = true;
            //        break;
            //    }
            //}

            dataGridViewListInfoBook.DataSource = Classes.Books.getBookWithBookName(bookName);
        }

        private void btnRefresh_Click(object sender, EventArgs e)
        {
            txbBookName.Text = string.Empty;
        }
    }
}