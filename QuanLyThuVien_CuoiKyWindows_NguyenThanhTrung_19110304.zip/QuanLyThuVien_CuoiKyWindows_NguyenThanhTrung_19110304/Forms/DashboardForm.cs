﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

using QuanLyThuVien_CuoiKyWindows_NguyenThanhTrung_19110304.Forms.Books;
using QuanLyThuVien_CuoiKyWindows_NguyenThanhTrung_19110304.Forms;
using QuanLyThuVien_CuoiKyWindows_NguyenThanhTrung_19110304.Forms.Users;
using QuanLyThuVien_CuoiKyWindows_NguyenThanhTrung_19110304.Forms.BorrowBooks;

namespace QuanLyThuVien_CuoiKyWindows_NguyenThanhTrung_19110304.Forms
{
    public partial class DashboardForm : Form
    {
        
        public DashboardForm()
        {
            InitializeComponent();
        }

        private void exitToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if(MessageBox.Show("Are you close program?", "Close Program", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                Application.Exit();
        }

        private void addNewBookToolStripMenuItem_Click(object sender, EventArgs e)
        {
            //Classes.TrungHelper.boolSendEmailRecoverAccount("quocthaierror@gmail.com");
            AddBooksForm addBooksForm = new AddBooksForm();
            addBooksForm.ShowDialog();
        }

        private void DashboardForm_Load(object sender, EventArgs e)
        {
            // Kiểm tra người dùng đã login chưa
            if (!Classes.Users.isLogin)
                Application.Exit();

            string role = Classes.Users.InfoUserLogin["role"].ToString();

            // Phân quyền chức năng
            if(role == Classes.Users.User_Role.Student.ToString())
            {
                booksToolStripMenuItem.Visible = false;
                usersToolStripMenuItem.Visible = false;
                settingsToolStripMenuItem.Visible = false;   
            }
            else if(role == Classes.Users.User_Role.Teacher.ToString())
            {
                booksToolStripMenuItem.Visible = false;
                usersToolStripMenuItem.Visible = false;
                settingsToolStripMenuItem.Visible = false;
            }

            lbUsername.Text = string.Format("Hello: {0}\nRole: {1}", Classes.Users.InfoUserLogin["username"], Classes.Users.InfoUserLogin["role"]);
        }

        private void viewBookToolStripMenuItem_Click(object sender, EventArgs e)
        {
            ViewBooksForm vb = new ViewBooksForm();
            vb.ShowDialog();
        }

        private void bookTypeToolStripMenuItem_Click(object sender, EventArgs e)
        {
            AddBookTypeForm addBookTypeForm = new AddBookTypeForm();
            addBookTypeForm.ShowDialog();
        }

        private void addUserToolStripMenuItem_Click(object sender, EventArgs e)
        {
            AddUsersForm addUsersForm = new AddUsersForm();
            addUsersForm.ShowDialog();
        }

        private void viewUserToolStripMenuItem_Click(object sender, EventArgs e)
        {
            ViewUsersForm vu = new ViewUsersForm();
            vu.ShowDialog();
        }

        private void settingsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Settings settings = new Settings();
            settings.ShowDialog();
        }

        private void myAccountToolStripMenuItem_Click(object sender, EventArgs e)
        {
            EditMyAccountForm editMyAccountForm = new EditMyAccountForm();
            editMyAccountForm.ShowDialog();
        }

        private void issueBooksToolStripMenuItem_Click(object sender, EventArgs e)
        {
            MenuBooksForm menuBooksForm = new MenuBooksForm();
            menuBooksForm.ShowDialog();
        }

        private void historyToolStripMenuItem_Click(object sender, EventArgs e)
        {
            ViewListBookBorrowingForm viewListBookBorrowingForm = new ViewListBookBorrowingForm();
            viewListBookBorrowingForm.ShowDialog();
        }
    }
}
