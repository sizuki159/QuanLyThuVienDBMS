﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using QuanLyThuVien_Nhom05.Classes;

namespace QuanLyThuVien_Nhom05.Forms.Books
{
    public partial class AddBooksForm : Form
    {
        public AddBooksForm()
        {
            InitializeComponent();
        }

        private void AddBooksForm_Load(object sender, EventArgs e)
        {
            Classes.Books.loadComboBoxBookType(comboBoxType);
            // Set default Properties
            rbtnStatusActive.Checked = true;
            if (comboBoxType.Items.Count <= 0)
            {
                MessageBox.Show("No book type, please add book type first", "Action Fail", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                this.Close();
                AddBookTypeForm addBookTypeForm = new AddBookTypeForm();
                addBookTypeForm.ShowDialog();
            }
        }

        private void pictureBoxUploadImage_Click(object sender, EventArgs e)
        {
            OpenFileDialog open = new OpenFileDialog();
            // image filters  
            open.Filter = "Image Files(*.jpg; *.png; *.jpeg; *.gif; *.bmp)|*.jpg; *.png; *.jpeg; *.gif; *.bmp";
            if (open.ShowDialog() == DialogResult.OK)
            {
                // display image in picture box  
                pictureBoxBookPreview.Image = new Bitmap(open.FileName);
            }
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            try
            {
                Classes.Books book = new Classes.Books();
                book.Name = txbName.Text;
                book.AuthorName = txbAuthorName.Text;

                Classes.Books.Book_Type booktype = comboBoxType.SelectedItem as Classes.Books.Book_Type;
                if(booktype == null)
                {
                    MessageBox.Show("Please Choose Book Type", "Action Fail", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }

                book.BookType = int.Parse(booktype.ID);
                book.Price = (float)nrudPrice.Value;
                book.Quantity = (int)nrudQuantity.Value;
                book.Description = rtbDescription.Text;

                if(rbtnStatusActive.Checked)
                    book.Status = Classes.Books.Book_Status.Active;
                else if (rbtnStatusHiden.Checked)
                    book.Status = Classes.Books.Book_Status.Hiden;
                else if (rbtnStatusPending.Checked)
                    book.Status = Classes.Books.Book_Status.Pending;
                else
                {
                    MessageBox.Show("Please Choose Status!!!", "Action Fail", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }


                book.Image = pictureBoxBookPreview.Image;

                if (ValidateForm("add"))
                    if (book.isInsert())
                        MessageBox.Show("Add Book Success", "Action Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    else
                        MessageBox.Show("Add Book Fail", "Action Fail", MessageBoxButtons.OK, MessageBoxIcon.Error);
                else
                    MessageBox.Show("Data input errors", "Action Fail", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Exception Errors", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            
        }

        private bool ValidateForm(string operation)
        {
            if (operation == "add")
            {
                if (string.IsNullOrEmpty(txbName.Text) || string.IsNullOrEmpty(txbAuthorName.Text)
                                        || string.IsNullOrEmpty(rtbDescription.Text))
                    return false;
                return true;
            }
            return false;
        }
    }
}