﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace QuanLyThuVien_Nhom05.Forms.BorrowBooks
{
    public partial class BookInfoForm : Form
    {
        static int bookID = -1;
        public BookInfoForm()
        {
            InitializeComponent();
        }

        public BookInfoForm(int ID, string bookname, string typename, string authorname, string price, string quantity, string description, Image images)
        {
            bookID = ID;

            InitializeComponent();

            labelTitle.Text = bookname;
            txbBookType.Text = typename;
            txbAuthorName.Text = authorname;
            txbPrice.Text = price;
            txbQuantity.Text = quantity;
            rtbDescription.Text = description;
            pictureBoxBookPreview.Image = images;

            if(int.Parse(quantity) <= 0)
                labelNotificationQuantity.Text = "Out of book";
        }

        private void btnBorrowBook_Click(object sender, EventArgs e)
        {
            DialogResult questionBorrowBook = MessageBox.Show("Are you sure you want to borrow this book?", "Question Action", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (questionBorrowBook == DialogResult.No)
                return;

            Classes.Borrows borrow = new Classes.Borrows();
            borrow.BookID = bookID;
            borrow.UserCode = Classes.Users.InfoUserLogin["code"].ToString();
            borrow.Status = Classes.Borrows.Status_Borrow.Borrowing;

            // Check là có đang mượn cuốn sách này hay không
            if(Classes.Borrows.isCheckBookBorring(borrow.BookID, borrow.UserCode))
            {
                MessageBox.Show("You are already borrowing this book, please return it on time then you can borrow it again", "Action Fail", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                this.Close();
                return;
            }

            if (!Classes.Books.isCheckBookAvailableQuantity(bookID.ToString()))
            {
                MessageBox.Show("Out of books. Please, come back later!", "Action Fail", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                this.Close();
                return;
            }
            else
            {
                if(Classes.Books.isTakeOneBook(bookID.ToString()))
                {
                    if (borrow.isInsert())
                    {
                        MessageBox.Show("Borrow Book Success", "Action Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        this.Close();
                    }
                    else
                    {
                        MessageBox.Show("Borrow Book Fail", "Action Fail", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        return;
                    }
                }
                else
                {
                    MessageBox.Show("Take Book From Library Fail", "Action Fail", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }

            }
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
