﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace QuanLyThuVien_Nhom05.Forms.BorrowBooks
{
    public partial class MenuBooksForm : Form
    {
        public MenuBooksForm()
        {
            InitializeComponent();

            Classes.TrungHelper.setDefaultDataGridView(dataGridViewListInfoBook, Classes.Books.getBooksWithStatus(Classes.Books.Book_Status.Active, Classes.Books.Book_Type.BookType_Status.Active));
            //dataGridViewListInfoBook.DataSource = Classes.Books.getBooks();
        }

        private void dataGridViewListInfoBook_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            int bookID = int.Parse(dataGridViewListInfoBook.CurrentRow.Cells[0].Value.ToString());
            string bookname = dataGridViewListInfoBook.CurrentRow.Cells[1].Value.ToString();
            string authorname = dataGridViewListInfoBook.CurrentRow.Cells[2].Value.ToString();
            string typename = dataGridViewListInfoBook.CurrentRow.Cells[3].Value.ToString();
            string price = dataGridViewListInfoBook.CurrentRow.Cells[4].Value.ToString();
            string quantity = dataGridViewListInfoBook.CurrentRow.Cells[5].Value.ToString();
            string description = dataGridViewListInfoBook.CurrentRow.Cells[6].Value.ToString();

            Image images;
            try
            {
                Byte[] dataImage = new Byte[0];
                dataImage = (Byte[])dataGridViewListInfoBook.CurrentRow.Cells[8].Value;
                MemoryStream mem = new MemoryStream(dataImage);
                images = Image.FromStream(mem);
            }
            catch
            {
                images = null;
            }

            BookInfoForm bookInfoForm = new BookInfoForm(bookID, bookname, typename, authorname, price, quantity, description, images);
            bookInfoForm.ShowDialog();

            string search = string.Format("%{0}%", txbBookName.Text);
            dataGridViewListInfoBook.DataSource = Classes.Books.getBooksWithStatus(Classes.Books.Book_Status.Active, Classes.Books.Book_Type.BookType_Status.Active, search);

        }

        private void txbBookName_TextChanged(object sender, EventArgs e)
        {
            string search = string.Format("%{0}%", txbBookName.Text);
            dataGridViewListInfoBook.DataSource = Classes.Books.getBooksWithStatus(Classes.Books.Book_Status.Active, Classes.Books.Book_Type.BookType_Status.Active, search);
        }

        private void btnRefresh_Click(object sender, EventArgs e)
        {
            txbBookName.Text = string.Empty;
        }
    }
}
