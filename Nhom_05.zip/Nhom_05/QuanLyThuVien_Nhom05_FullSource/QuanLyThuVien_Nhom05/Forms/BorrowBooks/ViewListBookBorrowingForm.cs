﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace QuanLyThuVien_Nhom05.Forms.BorrowBooks
{
    public partial class ViewListBookBorrowingForm : Form
    {
        private static DateTime borrowTime;
        private string borrowID = "";

        string userCode = Classes.Users.InfoUserLogin["code"].ToString();
        public ViewListBookBorrowingForm()
        {
            InitializeComponent();
        }

        private void ViewListBookBorrowingForm_Load(object sender, EventArgs e)
        {
            panelInfoBook.Visible = false;
            Classes.TrungHelper.setDefaultDataGridView(dataGridViewListInfoBook, Classes.Borrows.getListHistoryBorrow(userCode));
            //dataGridViewListInfoBook.DataSource = Classes.Borrows.getListHistoryBorrow(userCode);
            dataGridViewListInfoBook.Columns["borrow_id"].Visible = false;
        }

        static int bookID = -1;
        private void dataGridViewListInfoBook_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            if (dataGridViewListInfoBook.CurrentRow.Cells[1].Value != null)
                bookID = int.Parse(dataGridViewListInfoBook.CurrentRow.Cells[1].Value.ToString());
            else
            {
                MessageBox.Show("Lỗi không convert được ID sách", "Action Fail", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            borrowID = dataGridViewListInfoBook.CurrentRow.Cells[0].Value.ToString();
            panelInfoBook.Visible = true;
            DataTable infoBook = Classes.Borrows.getInfoOneBookBorrowing(borrowID, bookID.ToString(), userCode);
            string status = infoBook.Rows[0]["status"].ToString();
            txbName.Text = infoBook.Rows[0]["bookname"].ToString();
            txbAuthorName.Text = infoBook.Rows[0]["authorname"].ToString();
            rtbDescription.Text = infoBook.Rows[0]["description"].ToString();

            if(status == Classes.Borrows.Status_Borrow.Borrowing.ToString())
            {
                btnAction.Visible = true;
                btnAction.Text = "Return Book Now";
                borrowTime = DateTime.Parse(infoBook.Rows[0]["return_time"].ToString());
                DateTime timeNow = DateTime.Now;

                int compare = DateTime.Compare(borrowTime, timeNow);
                if (compare > 0)
                {
                    timer1.Start();
                    labelStatus.ForeColor = Color.Green;
                }
                else
                {
                    timer1.Stop();
                    labelStatus.ForeColor = Color.Red;
                    labelStatus.Text = "Out of date";
                }
            }
            else
            {
                timer1.Stop();
                btnAction.Visible = false;
                labelStatus.ForeColor = Color.Green;
                labelStatus.Text = status;
            }


            try
            {
                Byte[] dataImage = new Byte[0];
                dataImage = (Byte[])(infoBook.Rows[0]["images"]);
                MemoryStream mem = new MemoryStream(dataImage);
                pictureBoxBookPreview.Image = Image.FromStream(mem);
            }
            catch
            {
                pictureBoxBookPreview.Image = null;
            }
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            TimeSpan timeRemaing = borrowTime.Subtract(DateTime.Now);
            timeRemaing = timeRemaing.Subtract(TimeSpan.FromSeconds(1));
            labelStatus.Text = "Borrowing - Time remaining " + timeRemaing.ToString(@"dd\-hh\:mm\:ss");
        }

        private void btnAction_Click(object sender, EventArgs e)
        {
            DialogResult questionReturnBook = MessageBox.Show("Are you sure you want to return this book?", "Question Action", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (questionReturnBook == DialogResult.No)
                return;

            if (btnAction.Text == "Return Book Now")
            {
                if ( Classes.Borrows.returnBook(bookID.ToString(), userCode) )
                {
                    MessageBox.Show("Return this book success!", "Question Action", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    panelInfoBook.Visible = false;
                    ViewListBookBorrowingForm_Load(null, null);
                }
            }    
        }

        private void txbBookName_TextChanged(object sender, EventArgs e)
        {
            string search = string.Format("%{0}%", txbBookName.Text);
            dataGridViewListInfoBook.DataSource = Classes.Borrows.getListHistoryBorrow(userCode, search);
        }

        private void btnRefresh_Click(object sender, EventArgs e)
        {
            txbBookName.Text = string.Empty;
        }
    }
}
