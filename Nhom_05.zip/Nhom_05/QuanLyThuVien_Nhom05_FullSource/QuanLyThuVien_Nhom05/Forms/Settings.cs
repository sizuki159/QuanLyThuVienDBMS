﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace QuanLyThuVien_Nhom05.Forms
{
    public partial class Settings : Form
    {
        public Settings()
        {
            InitializeComponent();
        }

        private void loadDataAllControl()
        {
            string gmail = Classes.Settings.getValue(Classes.Settings.KeyGmail);
            string passEmail = Classes.Settings.getValue(Classes.Settings.KeyPassEmail);
            int hourOpen = Convert.ToInt32(Classes.Settings.getValue(Classes.Settings.KeyHourOpen));
            int hourClose = Convert.ToInt32(Classes.Settings.getValue(Classes.Settings.KeyHourClose));


            txbGmail.Text = gmail;
            txbPassGmail.Text = passEmail;
            numericUpDownOpen.Value = hourOpen;
            numericUpDownClose.Value = hourClose;
        }

        private void Settings_Load(object sender, EventArgs e)
        {
            loadDataAllControl();
        }

        private void btnSaveGmail_Click(object sender, EventArgs e)
        {
            string newEmail = txbGmail.Text;
            string newPassEmail = txbPassGmail.Text;

            if(!newEmail.Contains("@gmail.com"))
            {
                MessageBox.Show("Hiện tại chỉ hỗ trợ Gmail. Vui lòng nhập đúng định dạng của Gmail", "Action Fail", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            bool isUpdated = Classes.Settings.updateEmail(newEmail, newPassEmail);
            if(isUpdated)
            {
                MessageBox.Show("Update Email Success", "Action Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                loadDataAllControl();
            }
        }

        private void btnSaveTime_Click(object sender, EventArgs e)
        {
            int hourOpen = Convert.ToInt32(numericUpDownOpen.Value);
            int hourClose = Convert.ToInt32(numericUpDownClose.Value);


            if (hourOpen >= hourClose)
            {
                MessageBox.Show("Thời gian không hợp lệ, thời gian đóng cửa lại sớm hơn mở cửa ??? :D ???", "Action Fail", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            if(Classes.Settings.updateValue(Classes.Settings.KeyHourOpen, hourOpen.ToString()) && Classes.Settings.updateValue(Classes.Settings.KeyHourClose, hourClose.ToString()))
            {
                MessageBox.Show("Update Hour Library Success", "Action Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }

        }
    }
}