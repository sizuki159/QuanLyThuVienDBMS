﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

using QuanLyThuVien_Nhom05.Forms.Books;
using QuanLyThuVien_Nhom05.Forms;
using QuanLyThuVien_Nhom05.Forms.Users;
using QuanLyThuVien_Nhom05.Forms.BorrowBooks;

namespace QuanLyThuVien_Nhom05.Forms
{
    public partial class DashboardForm : Form
    {
        private string userCode = Classes.Users.InfoUserLogin["code"].ToString();
        public DashboardForm()
        {
            InitializeComponent();
        }

        private void exitToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if(MessageBox.Show("Are you close program?", "Close Program", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                Application.Exit();
        }

        private void addNewBookToolStripMenuItem_Click(object sender, EventArgs e)
        {
            //Classes.TrungHelper.boolSendEmailRecoverAccount("quocthaierror@gmail.com");
            AddBooksForm addBooksForm = new AddBooksForm();
            addBooksForm.ShowDialog();
        }

        private void DashboardForm_Load(object sender, EventArgs e)
        {
            // Kiểm tra người dùng đã login chưa
            if (!Classes.Users.isLogin)
                Application.Exit();

            string role = Classes.Users.InfoUserLogin["role"].ToString();

            // Phân quyền chức năng
            if(role == Classes.Users.User_Role.Student.ToString())
            {
                booksToolStripMenuItem.Visible = false;
                usersToolStripMenuItem.Visible = false;
                settingsToolStripMenuItem.Visible = false;   
            }
            else if(role == Classes.Users.User_Role.Teacher.ToString())
            {
                booksToolStripMenuItem.Visible = false;
                usersToolStripMenuItem.Visible = false;
                settingsToolStripMenuItem.Visible = false;
            }

            lbUsername.Text = string.Format("Hello: {0}\nRole: {1}", Classes.Users.InfoUserLogin["username"], Classes.Users.InfoUserLogin["role"]);

            // Thông báo sách sắp hết hạn và đã hết hạn
            string messages = string.Empty;

            DataTable listBookAboutToExpire = Classes.Borrows.getListBorrowingAboutToExpire(userCode);
            if(listBookAboutToExpire.Rows.Count > 0)
            {
                messages = string.Format("- Bạn đang có {0} cuốn sách sắp đến hạn trả\n", listBookAboutToExpire.Rows.Count);
                foreach(DataRow row in listBookAboutToExpire.Rows)
                {
                    messages += string.Format("\t+ {0} - cần trả trước {1}\n", row["bookname"].ToString(), row["return_time"].ToString());
                }
                messages += "\n\n";
            }
            DataTable listBorrowingExpired = Classes.Borrows.getListBorrowingExpired(userCode);
            if (listBorrowingExpired.Rows.Count > 0)
            {
                messages += string.Format("- Bạn đã quá hạn {0} cuốn sách\n", listBorrowingExpired.Rows.Count);
                foreach (DataRow row in listBorrowingExpired.Rows)
                {
                    messages += string.Format("\t+ {0} - cần trả trước {1}\n", row["bookname"].ToString(), row["return_time"].ToString());
                }
            }
            if(messages != string.Empty)
                MessageBox.Show(messages, "Notification Return Book", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        private void viewBookToolStripMenuItem_Click(object sender, EventArgs e)
        {
            ViewBooksForm vb = new ViewBooksForm();
            vb.ShowDialog();
        }

        private void bookTypeToolStripMenuItem_Click(object sender, EventArgs e)
        {
            AddBookTypeForm addBookTypeForm = new AddBookTypeForm();
            addBookTypeForm.ShowDialog();
        }

        private void addUserToolStripMenuItem_Click(object sender, EventArgs e)
        {
            AddUsersForm addUsersForm = new AddUsersForm();
            addUsersForm.ShowDialog();
        }

        private void viewUserToolStripMenuItem_Click(object sender, EventArgs e)
        {
            ViewUsersForm vu = new ViewUsersForm();
            vu.ShowDialog();
        }

        private void settingsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Settings settings = new Settings();
            settings.ShowDialog();
        }

        private void myAccountToolStripMenuItem_Click(object sender, EventArgs e)
        {
            EditMyAccountForm editMyAccountForm = new EditMyAccountForm();
            editMyAccountForm.ShowDialog();
        }

        private void issueBooksToolStripMenuItem_Click(object sender, EventArgs e)
        {
            MenuBooksForm menuBooksForm = new MenuBooksForm();
            menuBooksForm.ShowDialog();
        }

        private void historyToolStripMenuItem_Click(object sender, EventArgs e)
        {
            ViewListBookBorrowingForm viewListBookBorrowingForm = new ViewListBookBorrowingForm();
            viewListBookBorrowingForm.ShowDialog();
        }
    }
}
