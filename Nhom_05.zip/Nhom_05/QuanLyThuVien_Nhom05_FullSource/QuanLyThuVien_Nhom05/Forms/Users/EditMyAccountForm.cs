﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace QuanLyThuVien_Nhom05.Forms.Users
{
    public partial class EditMyAccountForm : Form
    {
        public EditMyAccountForm()
        {
            InitializeComponent();
        }

        private void reloadControls()
        {
            string userID = Classes.Users.InfoUserLogin["code"].ToString();
            DataTable infoUser = Classes.Users.getUserWithCode(userID.ToString());
            txbFullName.Text = infoUser.Rows[0]["fullname"].ToString();
            txbUsername.Text = infoUser.Rows[0]["username"].ToString();
            txbPassword.Text = infoUser.Rows[0]["password"].ToString();
            txbCode.Text = infoUser.Rows[0]["code"].ToString();
            txbEmail.Text = infoUser.Rows[0]["email"].ToString();
            if (infoUser.Rows[0]["gender"].ToString().Trim().ToLower() == "male")
                rbtnMale.Checked = true;
            else
                rbtnFemale.Checked = true;

            try
            {
                DateTime birthdate = DateTime.Parse(infoUser.Rows[0]["birthdate"].ToString());
                dtpBirthdate.Value = birthdate;
            }
            catch { }


            try
            {
                Byte[] dataImage = new Byte[0];
                dataImage = (Byte[])(infoUser.Rows[0]["images"]);
                MemoryStream mem = new MemoryStream(dataImage);
                pictureBoxPreview.Image = Image.FromStream(mem);
            }
            catch
            {
                pictureBoxPreview.Image = null;
            }
        }


        private void pictureBoxUploadImage_Click(object sender, EventArgs e)
        {
            OpenFileDialog open = new OpenFileDialog();
            // image filters  
            open.Filter = "Image Files(*.jpg; *.png; *.jpeg; *.gif; *.bmp)|*.jpg; *.png; *.jpeg; *.gif; *.bmp";
            if (open.ShowDialog() == DialogResult.OK)
            {
                // display image in picture box  
                pictureBoxPreview.Image = new Bitmap(open.FileName);
            }
        }

        private void EditMyAccountForm_Load(object sender, EventArgs e)
        {
            reloadControls();
        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {
            string fullname = txbFullName.Text;
            string password = txbPassword.Text;
            Image images = pictureBoxPreview.Image;
            bool isUpdateMyAccount = Classes.Users.isEditMyAccount(fullname, password, images, Classes.Users.InfoUserLogin["code"].ToString());
            if(isUpdateMyAccount)
            {
                MessageBox.Show("Your account has been updated!", "Action Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                reloadControls();
            }
            else
            {
                MessageBox.Show("Update account fail", "Action Fail", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }

        }
    }
}