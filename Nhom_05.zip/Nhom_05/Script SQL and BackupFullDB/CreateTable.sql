﻿--Tạo các bảng

create table users(
	id int not null identity(1,1) primary key,
	fullname nvarchar(150),
	username nvarchar(150) unique not null,
	password varchar(150) not null,
	gender varchar(10),
	birthdate datetime,
	role varchar(10) not null,
	status varchar(10) not null,
	images image,
	created_time datetime,
	modified_time datetime,
	code nvarchar(10) unique,
	email nvarchar(150) unique
)

create table book_type(
	id int not null identity(1,1) primary key,
	typename nvarchar(150) unique not null,
	status varchar(10) not null,
	created_time datetime,
	modified_time datetime,
)


create table books(
	id int not null identity(1,1) primary key,
	bookname nvarchar(150) not null,
	authorname nvarchar(150),
	booktype int not null,
	price float,
	quantity int not null,
	description text,
	status varchar(10) not null,
	images image,
	created_time datetime,
	modified_time datetime,
	
	foreign key(booktype) references book_type(id),
	check(quantity >= 0)
)

create table borrows
(
	id int identity(1,1) primary key,
	book_id int,
	user_code nvarchar(10),
	status nvarchar(10) not null,
	borrow_time datetime not null,
	return_time datetime not null,

	foreign key (book_id) references books(id),
	foreign key (user_code) references users(code),
)

create table settings
(
	keys nvarchar(30) primary key,
	value nvarchar(50) not null
)

INSERT INTO settings VALUES('gmail', 'systemGmail')
INSERT INTO settings VALUES('passemail', 'passSystemGmail')
INSERT INTO settings VALUES('hourOpen', '7')
INSERT INTO settings VALUES('hourClose', '20')

create table recover_code
(
	id int primary key identity(1,1),
	user_id int,
	code_recover nvarchar(10) not null,
	expiry_date datetime not null,
	status nvarchar(10) not null,
	foreign key (user_id) references users(id),
)


-- Những bảng này ở thời điểm này vẫn chưa cần thiết, tính năng sẽ update trong tương lai
create table notification_user(
	id int primary key identity(1,1),
	user_id int,
	title nvarchar(300),
	content nvarchar(4000),
	status nvarchar(10),
	created_time datetime
)

create table employee
(
	id int primary key identity(1,1),
	fullname nvarchar(150),
	working nvarchar(150) not null,
	images image
)